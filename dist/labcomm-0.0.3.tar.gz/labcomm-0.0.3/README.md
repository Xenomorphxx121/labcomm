# labcomm
A fast binary protocol for interacting with integrated circuit demonstration boards.

See the description of Labcomm here in the Wiki
https://github.com/Xenomorphxx121/labcomm/wiki