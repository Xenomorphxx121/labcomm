/****************************************************************************
 * BCB606 Stowe Push button                                                 *
 * Steve Martin                                                             *
 * June 1, 2023                                                             *
 ****************************************************************************/
#ifndef BCB606_PUSHBUTTON_B
#define BCB606_PUSHBUTTON_B

void BCB606_get_push_button();

#endif